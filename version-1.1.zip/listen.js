const index = require('./index')
const app = index.app;
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
  })
